param(
    [ValidateSet("Toggle", "Install", "Uninstall")]
    [string]$Action = "Toggle",
    [string]$GameDir,
    [string]$PackageDir = $PSScriptRoot,
    [string]$UserDataDir,
    [switch]$NoSaveSync
)

$ErrorActionPreference = "Stop"

$AssemblyName = "sts2_lan_connect"

function Write-Info {
    param([string]$Message)
    Write-Host "[sts2-lan-connect] $Message"
}

function Resolve-PackageDir {
    param([string]$Candidate)

    if (-not $Candidate) {
        throw "Package directory is empty."
    }

    $dllPath = Join-Path $Candidate "$AssemblyName.dll"
    $pckPath = Join-Path $Candidate "$AssemblyName.pck"
    if ((Test-Path $dllPath) -and (Test-Path $pckPath)) {
        return (Resolve-Path $Candidate).Path
    }

    throw "Package directory '$Candidate' does not contain $AssemblyName.dll and $AssemblyName.pck"
}

function Get-SteamLibraryRoots {
    $roots = [System.Collections.Generic.List[string]]::new()

    foreach ($candidate in @($env:STS2_ROOT, $env:ProgramFiles.TrimEnd('\') + "\Steam", ${env:ProgramFiles(x86)}.TrimEnd('\') + "\Steam", $env:LOCALAPPDATA.TrimEnd('\') + "\Programs\Steam")) {
        if ($candidate -and (Test-Path $candidate)) {
            [void]$roots.Add($candidate)
        }
    }

    foreach ($regPath in @("HKCU:\Software\Valve\Steam", "HKLM:\Software\Valve\Steam", "HKLM:\Software\WOW6432Node\Valve\Steam")) {
        try {
            $steamPath = (Get-ItemProperty -Path $regPath -ErrorAction Stop).SteamPath
            if ($steamPath -and (Test-Path $steamPath)) {
                [void]$roots.Add($steamPath)
            }
        } catch {
        }

        try {
            $installPath = (Get-ItemProperty -Path $regPath -ErrorAction Stop).InstallPath
            if ($installPath -and (Test-Path $installPath)) {
                [void]$roots.Add($installPath)
            }
        } catch {
        }
    }

    $expanded = [System.Collections.Generic.List[string]]::new()
    foreach ($root in $roots | Select-Object -Unique) {
        [void]$expanded.Add($root)
        $libraryFile = Join-Path $root "steamapps\libraryfolders.vdf"
        if (-not (Test-Path $libraryFile)) {
            continue
        }

        $content = Get-Content -Path $libraryFile -Raw
        foreach ($match in [regex]::Matches($content, '"path"\s*"([^"]+)"')) {
            $libraryPath = $match.Groups[1].Value -replace '\\\\', '\'
            if ($libraryPath -and (Test-Path $libraryPath)) {
                [void]$expanded.Add($libraryPath)
            }
        }
    }

    return $expanded | Select-Object -Unique
}

function Resolve-GameDir {
    param([string]$Candidate)

    if ($Candidate) {
        if (Test-Path (Join-Path $Candidate "mods")) {
            return (Resolve-Path $Candidate).Path
        }
        if (Test-Path (Join-Path $Candidate "Slay the Spire 2.exe")) {
            return (Resolve-Path $Candidate).Path
        }
    }

    foreach ($root in Get-SteamLibraryRoots) {
        $candidateDir = Join-Path $root "steamapps\common\Slay the Spire 2"
        if (Test-Path $candidateDir) {
            return (Resolve-Path $candidateDir).Path
        }
    }

    throw "Could not locate the Slay the Spire 2 game directory. Re-run with -GameDir <path>."
}

function Resolve-UserDataDir {
    param([string]$Candidate)

    foreach ($path in @($Candidate, $env:STS2_USERDATA_DIR, (Join-Path $env:APPDATA "SlayTheSpire2"), (Join-Path $env:LOCALAPPDATA "SlayTheSpire2"))) {
        if ($path -and (Test-Path $path)) {
            return (Resolve-Path $path).Path
        }
    }

    return (Join-Path $env:APPDATA "SlayTheSpire2")
}

function Test-ModInstalled {
    param([string]$TargetModDir)

    if (-not (Test-Path $TargetModDir)) {
        return $false
    }

    return $null -ne (Get-ChildItem -Path $TargetModDir -Force -ErrorAction SilentlyContinue | Select-Object -First 1)
}

function Uninstall-Mod {
    param([string]$TargetModDir)

    if (-not (Test-Path $TargetModDir)) {
        Write-Info "Mod is not installed. Nothing to uninstall."
        exit 0
    }

    Write-Info "Uninstalling mod from: $TargetModDir"
    Remove-Item -Path $TargetModDir -Recurse -Force
    Write-Info "Mod uninstalled."
    exit 0
}

function Backup-ProfileIfNeeded {
    param(
        [string]$SourceProfile,
        [string]$BackupProfile
    )

    if (-not (Test-Path $SourceProfile)) {
        return $false
    }

    $existingFiles = Get-ChildItem -Path $SourceProfile -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $existingFiles) {
        return $false
    }

    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $BackupProfile) | Out-Null
    Copy-Item -Path $SourceProfile -Destination $BackupProfile -Recurse -Force
    return $true
}

function Sync-ProfileSaves {
    param(
        [string]$PlatformName,
        [string]$UserDir,
        [System.IO.DirectoryInfo]$ProfileDir,
        [string]$BackupRoot,
        [ref]$ProfilesSynced,
        [ref]$FilesCopied,
        [ref]$BackupsCreated
    )

    $sourceSaves = Join-Path $ProfileDir.FullName "saves"
    if (-not (Test-Path $sourceSaves)) {
        return
    }

    $destProfile = Join-Path (Join-Path $UserDir "modded") $ProfileDir.Name
    $destSaves = Join-Path $destProfile "saves"

    if (Backup-ProfileIfNeeded -SourceProfile $destProfile -BackupProfile (Join-Path $BackupRoot "$PlatformName\$([System.IO.Path]::GetFileName($UserDir))\$($ProfileDir.Name)")) {
        $BackupsCreated.Value++
    }

    New-Item -ItemType Directory -Force -Path $destSaves | Out-Null

    foreach ($sourceFile in Get-ChildItem -Path $sourceSaves -File -Recurse) {
        $relativePath = $sourceFile.FullName.Substring($sourceSaves.Length).TrimStart('\', '/')
        $destFile = Join-Path $destSaves $relativePath
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destFile) | Out-Null

        if ((-not (Test-Path $destFile)) -or ($sourceFile.LastWriteTimeUtc -gt (Get-Item $destFile).LastWriteTimeUtc)) {
            Copy-Item -Path $sourceFile.FullName -Destination $destFile -Force
            $FilesCopied.Value++
        }
    }

    $ProfilesSynced.Value++
}

$resolvedGameDir = Resolve-GameDir -Candidate $GameDir
$targetModDir = Join-Path (Join-Path $resolvedGameDir "mods") $AssemblyName
$manifestFileName = "$AssemblyName.json"
$effectiveAction = $Action

if ($Action -eq "Toggle") {
    if (Test-ModInstalled -TargetModDir $targetModDir) {
        $effectiveAction = "Uninstall"
    } else {
        $effectiveAction = "Install"
    }
}

if ($effectiveAction -eq "Uninstall") {
    Uninstall-Mod -TargetModDir $targetModDir
}

$resolvedPackageDir = Resolve-PackageDir -Candidate $PackageDir
$resolvedUserDataDir = Resolve-UserDataDir -Candidate $UserDataDir

New-Item -ItemType Directory -Force -Path $targetModDir | Out-Null

Write-Info "Installing mod files to: $targetModDir"
Copy-Item -Path (Join-Path $resolvedPackageDir "$AssemblyName.dll") -Destination $targetModDir -Force
Copy-Item -Path (Join-Path $resolvedPackageDir "$AssemblyName.pck") -Destination $targetModDir -Force

$manifestFile = Join-Path $resolvedPackageDir $manifestFileName
if (Test-Path $manifestFile) {
    Copy-Item -Path $manifestFile -Destination $targetModDir -Force
}

$defaultsFile = Join-Path $resolvedPackageDir "lobby-defaults.json"
$installedDefaultsFile = Join-Path $targetModDir "lobby-defaults.json"
if (Test-Path $installedDefaultsFile) {
    Remove-Item -Path $installedDefaultsFile -Force
}
if (Test-Path $defaultsFile) {
    Copy-Item -Path $defaultsFile -Destination $installedDefaultsFile -Force
}

$guideFile = Join-Path $resolvedPackageDir "STS2_LAN_CONNECT_USER_GUIDE_ZH.md"
if (Test-Path $guideFile) {
    Copy-Item -Path $guideFile -Destination $targetModDir -Force
}

if ($NoSaveSync) {
    Write-Info "Save sync skipped (-NoSaveSync)."
    exit 0
}

if (-not (Test-Path $resolvedUserDataDir)) {
    Write-Info "User data directory '$resolvedUserDataDir' does not exist yet. Installation finished without save sync."
    exit 0
}

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupRoot = Join-Path $resolvedUserDataDir "sts2_lan_connect_backups\$timestamp"
$profilesSynced = 0
$filesCopied = 0
$backupsCreated = 0

foreach ($platformName in @("steam", "default")) {
    $platformDir = Join-Path $resolvedUserDataDir $platformName
    if (-not (Test-Path $platformDir)) {
        continue
    }

    foreach ($userDir in Get-ChildItem -Path $platformDir -Directory) {
        foreach ($profileDir in Get-ChildItem -Path $userDir.FullName -Directory -Filter "profile*") {
            Sync-ProfileSaves -PlatformName $platformName -UserDir $userDir.FullName -ProfileDir $profileDir -BackupRoot $backupRoot -ProfilesSynced ([ref]$profilesSynced) -FilesCopied ([ref]$filesCopied) -BackupsCreated ([ref]$backupsCreated)
        }
    }
}

Write-Info "Save sync finished. Profiles scanned: $profilesSynced, files copied: $filesCopied, backups created: $backupsCreated"
Write-Info "This is a one-way sync from vanilla saves into modded saves. Re-run the installer any time you want to sync again."
